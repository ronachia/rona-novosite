import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Features from './components/Features';
import Therapy from './components/Therapy';
import News from './components/News';
import Partners from './components/Partners';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: '#f5f3ee' }}>
      <Header />
      <Hero />
      <About />
      <Features />
      <Therapy />
      <News />
      <Partners />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
